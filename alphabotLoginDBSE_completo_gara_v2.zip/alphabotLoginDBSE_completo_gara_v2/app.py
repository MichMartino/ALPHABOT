from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from AlphaBot import AlphaBot
import sqlite3
import RPi.GPIO as GPIO

app = Flask(__name__)
app.secret_key = '5555-fdd7-098b-c63'

# Configurazione Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Inizializza il robot
bot = AlphaBot()

# Path del database
DB_PATH = 'comandi.db'


def verifica_utente(username, password):
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    query = "SELECT * FROM login WHERE username = ? AND password = ?"
    cursore.execute(query, (username, password))
    user = cursore.fetchone()
    db.close()
    return user is not None


def verifica_comando(nome_comando):
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    query = "SELECT * FROM alphabot_comandi WHERE nome_comando = ?"
    cursore.execute(query, (nome_comando.lower(),))
    comando = cursore.fetchone()
    db.close()
    return comando


def registra_utente(username, password):
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    query = "INSERT INTO login (username, password) VALUES (?, ?)"
    cursore.execute(query, (username, password))
    db.commit()
    db.close()
    return True


# Classe User per Flask-Login
class User(UserMixin):
    def __init__(self, username):
        self.id = username


@login_manager.user_loader
def load_user(user_id):
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    query = "SELECT username FROM login WHERE username = ?"
    cursore.execute(query, (user_id,))
    user = cursore.fetchone()
    db.close()
    if user:
        return User(user_id)
    return None


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if verifica_utente(username, password):
            user = User(username)
            login_user(user)
            return redirect(url_for('controllo'))
    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


@app.route("/registrazione", methods=["GET", "POST"])
def registrazione():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if registra_utente(username, password):
            return redirect(url_for('login'))
    return render_template("registraUtente.html")


@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for('controllo'))
    return redirect(url_for('login'))


@app.route("/controllo")
@login_required
def controllo():
    return render_template("index.html", username=current_user.id)


@app.route("/cmd", methods=["POST"])
@login_required
def cmd():
    data = request.get_json()
    movimento = data.get("movimento", "")
    comando_db = verifica_comando(movimento)

    if comando_db:
        nome_cmd = comando_db[1]
        if nome_cmd == "avanti":
            bot.forward()
        elif nome_cmd == "indietro":
            bot.backward()
        elif nome_cmd == "sinistra":
            bot.left()
        elif nome_cmd == "destra":
            bot.right()
        elif nome_cmd == "stop":
            bot.stop()
        print(f"CMD: {nome_cmd}")
        return jsonify({"ok": True, "cmd": nome_cmd})

    return jsonify({"ok": False}), 400


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
