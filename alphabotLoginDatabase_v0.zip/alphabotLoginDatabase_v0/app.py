from flask import Flask, render_template, request, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from AlphaBot import AlphaBot
import sqlite3

app = Flask(__name__)
app.secret_key = '5555-fdd7-098b-c63'

#Configurazione Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

#Inizializza il robot
bot = AlphaBot()

#Path del database
DB_PATH = 'comandi.db'

def verifica_utente(username, password):
    #Mi collego al db e preparo il cursore
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    
    #Eseguo la query per verificare le credenziali
    query = "SELECT * FROM login WHERE username = ? AND password = ?"
    cursore.execute(query, (username, password))
    
    #Prendo il risultato della query
    user = cursore.fetchone()
    
    #Chiudo la connessione
    db.close()
    
    #Ritorno True se l'utente esiste, False altrimenti
    return user is not None

def verifica_comando(nome_comando):
    #Mi collego al db e preparo il cursore
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    
    #Eseguo la query per cercare il comando
    query = "SELECT * FROM alphabot_comandi WHERE nome_comando = ?"
    cursore.execute(query, (nome_comando.lower(),))
    
    #Prendo il risultato della query
    comando = cursore.fetchone()
    
    #Chiudo la connessione
    db.close()
    
    #Ritorno il comando trovato
    return comando

#Classe User per Flask-Login
class User(UserMixin):
    def __init__(self, username):
        self.id = username

@login_manager.user_loader
def load_user(user_id):
    #Mi collego al db e preparo il cursore
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    
    #Eseguo la query per verificare che l'utente esista
    query = "SELECT username FROM login WHERE username = ?"
    cursore.execute(query, (user_id,))
    
    #Prendo il risultato
    user = cursore.fetchone()
    
    #Chiudo la connessione
    db.close()
    
    if user:
        return User(user_id)
    return None

@app.route("/login", methods=["GET", "POST"])
def login():
    errore = None
    
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        #Verifica le credenziali tramite database
        if verifica_utente(username, password):
            user = User(username)
            login_user(user)
            return redirect(url_for('controllo'))
        else:
            errore = "Credenziali non valide. Riprova."
    
    return render_template("login.html", errore=errore)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for('controllo'))
    return redirect(url_for('login'))

@app.route("/controllo", methods=["GET", "POST"])
@login_required
def controllo():
    if request.method == "POST":
        #Recupera il comando inviato dal form
        movimento = request.form.get("movimento")
        
        #Verifica il comando nel database
        comando_db = verifica_comando(movimento)
        
        if comando_db:
            #Estrai le informazioni dal database (tupla: id, nome_comando, lettera)
            nome_cmd = comando_db[1]
            lettera_cmd = comando_db[2]
            
            #Esegui il comando corrispondente
            if nome_cmd == "avanti":
                bot.forward()
                print(f"Robot si muove AVANTI (comando: {lettera_cmd})")
                
            elif nome_cmd == "indietro":
                bot.backward()
                print(f"Robot si muove INDIETRO (comando: {lettera_cmd})")
                
            elif nome_cmd == "sinistra":
                bot.left()
                print(f"Robot gira a SINISTRA (comando: {lettera_cmd})")
                
            elif nome_cmd == "destra":
                bot.right()
                print(f"Robot gira a DESTRA (comando: {lettera_cmd})")
                
            elif nome_cmd == "stop":
                bot.stop()
                print(f"Robot si FERMA (comando: {lettera_cmd})")
        else:
            print(f"Comando '{movimento}' non trovato nel database")
    
    return render_template("index.html", username=current_user.id)

if __name__ == "__main__":
    #Avvia il server Flask in modalità debug
    app.run(host="0.0.0.0", port=5000, debug=False)