from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])

def controllo():
    if request.method == "POST":
        #Recupera il comando inviato dal form
        movimento = request.form["movimento"]
        
        #Qui andrebbero i comandi reali per l'AlphaBot con database
        #Al momento c'è simulazione tramite print
        
        if movimento == "Avanti":
            print("Robot si muove AVANTI")
            
        elif movimento == "Indietro":
            print("Robot si muove INDIETRO")
            
        elif movimento == "Sinistra":
            print("Robot gira a SINISTRA")
            
        elif movimento == "Destra":
            print("Robot gira a DESTRA")
            
        elif movimento == "Stop":
            print("Robot si FERMA")
        
        #Mostra la pagina con il risultato
        return render_template("result.html", movimento=movimento)
    
    else:
        #Mostra la pagina con i controlli
        return render_template("index.html")

if __name__ == "__main__":
    #Avvia il server Flask in modalità debug
    app.run(debug=True)