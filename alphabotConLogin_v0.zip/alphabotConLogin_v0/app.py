from flask import Flask, render_template, request, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from AlphaBot import AlphaBot

app = Flask(__name__)
app.secret_key = 'chiave_segreta_alphabot_2026'

#Configurazione Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

#Inizializza il robot
bot = AlphaBot()

#Credenziali di login
USERS = {
    'admin': {'password': 'password123'},
    'robot': {'password': 'alphabot'}
}

#Classe User per Flask-Login
class User(UserMixin):
    def __init__(self, username):
        self.id = username

@login_manager.user_loader
def load_user(user_id):
    if user_id in USERS:
        return User(user_id)
    return None

@app.route("/login", methods=["GET", "POST"])
def login():
    errore = None
    
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        #Verifica le credenziali
        if username in USERS and USERS[username]['password'] == password:
            user = User(username)
            login_user(user)
            return redirect(url_for('controllo'))
        else:
            errore = "Credenziali non valide. Riprova."
    
    return render_template("login.html", errore=errore)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for('controllo'))
    return redirect(url_for('login'))

@app.route("/controllo", methods=["GET", "POST"])
@login_required
def controllo():
    if request.method == "POST":
        #Recupera il comando inviato dal form
        movimento = request.form.get("movimento")
        
        if movimento == "Avanti":
            bot.forward()
            print("Robot si muove AVANTI")
            
        elif movimento == "Indietro":
            bot.backward()
            print("Robot si muove INDIETRO")
            
        elif movimento == "Sinistra":
            bot.left()
            print("Robot gira a SINISTRA")
            
        elif movimento == "Destra":
            bot.right()
            print("Robot gira a DESTRA")
            
        elif movimento == "Stop":
            bot.stop()
            print("Robot si FERMA")
    
    return render_template("index.html", username=current_user.id)

if __name__ == "__main__":
    #Avvia il server Flask in modalità debug
    app.run(host="0.0.0.0", port=5000, debug=False)