from flask import Flask, render_template, request, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from AlphaBot import AlphaBot
import sqlite3
import threading
import time
import RPi.GPIO as GPIO

app = Flask(__name__)
app.secret_key = '5555-fdd7-098b-c63'

#Configurazione Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

#Inizializza il robot
bot = AlphaBot()

#Path del database
DB_PATH = 'comandi.db'

#Variabile globale per lo stato dei sensori
stato_sensori = {
    'sinistra': False,
    'destra': False,
}

#Variabili per controllare il thread dei sensori
sensori_attivi = False
thread_sensori = None
lock_sensori = threading.Lock()

def monitoraggio_sensori():
    global stato_sensori, sensori_attivi
    
    while sensori_attivi:
        #Legge lo stato dei sensori
        sensoreSinistro = GPIO.input(bot.DL)
        sensoreDestro = GPIO.input(bot.DR)
        
        if sensoreSinistro == 0:
            print("Sensore sinistro attivato")
            stato_sensori['sinistra'] = True
            
            #Manovra di evasione ostacolo sinistro
            bot.backward()
            time.sleep(0.5)
            bot.right()
            time.sleep(0.5)
            bot.stop()
            
        elif sensoreDestro == 0:
            print("Sensore destro attivato")
            stato_sensori['destra'] = True
            
            #Manovra di evasione ostacolo destro
            bot.backward()
            time.sleep(0.5)
            bot.left()
            time.sleep(0.5)
            bot.stop()
            
        else:
            #Nessun ostacolo rilevato
            stato_sensori['sinistra'] = False
            stato_sensori['destra'] = False
        
        time.sleep(0.05)
    
    #Reset dello stato quando i sensori vengono disattivati
    stato_sensori['sinistra'] = False
    stato_sensori['destra'] = False
    print("Monitoraggio sensori disattivato")

def avvia_sensori():
    #Avvia il thread di monitoraggio sensori se non è già attivo
    global sensori_attivi, thread_sensori
    
    with lock_sensori:
        if not sensori_attivi:
            sensori_attivi = True
            thread_sensori = threading.Thread(target=monitoraggio_sensori, daemon=True)
            thread_sensori.start()
            print("Monitoraggio sensori avviato")

def ferma_sensori():
    #Ferma il thread di monitoraggio sensori
    global sensori_attivi
    
    with lock_sensori:
        if sensori_attivi:
            sensori_attivi = False
            print("Richiesta arresto monitoraggio sensori")

def verifica_utente(username, password):
    #Mi collego al db e preparo il cursore
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    
    #Eseguo la query per verificare le credenziali
    query = "SELECT * FROM login WHERE username = ? AND password = ?"
    cursore.execute(query, (username, password))
    
    #Prendo il risultato della query
    user = cursore.fetchone()
    
    #Chiudo la connessione
    db.close()
    
    #Ritorno True se l'utente esiste, False altrimenti
    return user is not None

def verifica_comando(nome_comando):
    #Mi collego al db e preparo il cursore
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    
    #Eseguo la query per cercare il comando
    query = "SELECT * FROM alphabot_comandi WHERE nome_comando = ?"
    cursore.execute(query, (nome_comando.lower(),))
    
    #Prendo il risultato della query
    comando = cursore.fetchone()
    
    #Chiudo la connessione
    db.close()
    
    #Ritorno il comando trovato
    return comando

#Classe User per Flask-Login
class User(UserMixin):
    def __init__(self, username):
        self.id = username

@login_manager.user_loader
def load_user(user_id):
    #Mi collego al db e preparo il cursore
    db = sqlite3.connect(DB_PATH)
    cursore = sqlite3.Cursor(db)
    
    #Eseguo la query per verificare che l'utente esista
    query = "SELECT username FROM login WHERE username = ?"
    cursore.execute(query, (user_id,))
    
    #Prendo il risultato
    user = cursore.fetchone()
    
    #Chiudo la connessione
    db.close()
    
    if user:
        return User(user_id)
    return None

@app.route("/login", methods=["GET", "POST"])
def login():
    
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        #Verifica le credenziali tramite database
        if verifica_utente(username, password):
            user = User(username)
            login_user(user)
            
            #Avvia il monitoraggio sensori quando l'utente fa login
            avvia_sensori()
            
            return redirect(url_for('controllo'))
    
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    #Ferma il monitoraggio sensori quando l'utente fa logout
    ferma_sensori()
    
    logout_user()
    return redirect(url_for('login'))

@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for('controllo'))
    return redirect(url_for('login'))

@app.route("/controllo", methods=["GET", "POST"])
@login_required
def controllo():
    if request.method == "POST":
        #Recupera il comando inviato dal form
        movimento = request.form.get("movimento")
        
        #Verifica il comando nel database
        comando_db = verifica_comando(movimento)
        
        if comando_db:
            #Estrai le informazioni dal database (tupla: id, nome_comando, lettera)
            nome_cmd = comando_db[1]
            lettera_cmd = comando_db[2]
            
            #Esegui il comando corrispondente
            if nome_cmd == "avanti":
                bot.forward()
                print(f"Robot si muove AVANTI (comando: {lettera_cmd})")
                
            elif nome_cmd == "indietro":
                bot.backward()
                print(f"Robot si muove INDIETRO (comando: {lettera_cmd})")
                
            elif nome_cmd == "sinistra":
                bot.left()
                print(f"Robot gira a SINISTRA (comando: {lettera_cmd})")
                
            elif nome_cmd == "destra":
                bot.right()
                print(f"Robot gira a DESTRA (comando: {lettera_cmd})")
                
            elif nome_cmd == "stop":
                bot.stop()
                print(f"Robot si FERMA (comando: {lettera_cmd})")
        else:
            print(f"Comando '{movimento}' non trovato nel database")
    
    #Passa lo stato dei sensori direttamente al template
    return render_template("index.html", 
                         username=current_user.id)

@app.route("/sensori")
@login_required
def sensori():
    #Pagina dedicata solo alla visualizzazione dei sensori
    return render_template("sensori.html",
                         username=current_user.id,
                         sensori=stato_sensori)

if __name__ == "__main__":
    #Avvia il server Flask
    app.run(host="0.0.0.0", port=5000, debug=False)