# ALPHABOT + SENSORE IR + THINGSBOARD
import paho.mqtt.client as mqtt   # pip install paho-mqtt
import RPi.GPIO as GPIO
import time
import json

# CONFIGURAZIONE: tuo ACCESS TOKEN di ThingsBoard
ACCESS_TOKEN = "LzMJPCF5PzxWWMVAnR04"

# Server ThingsBoard (usa demo per test)
THINGSBOARD_HOST = "192.168.1.104"
PORT = 1883
IR_PIN = 16

GPIO.setmode(GPIO.BCM)
GPIO.setup(IR_PIN, GPIO.IN)

# SETUP MQTT
client = mqtt.Client()

# Usa l’access token come username
client.username_pw_set(ACCESS_TOKEN)

# Funzione chiamata quando si connette
def on_connect(client, userdata, flags, rc):
    print("Connesso a ThingsBoard con codice:", rc)

# Funzione chiamata in caso di disconnessione
def on_disconnect(client, userdata, rc):
    print("Disconnesso! Tentativo di riconnessione...")

client.on_connect = on_connect
client.on_disconnect = on_disconnect

# Connessione al server
client.connect(THINGSBOARD_HOST, PORT, 60)

# Avvia gestione automatica rete (IMPORTANTE)
client.loop_start()

# LOOP PRINCIPALE
print("Avvio lettura sensore IR...")

last_state = None  # serve per inviare dati solo quando cambiano

try:
    while True:
        # Legge stato sensore (0 o 1)
        ir_state = GPIO.input(IR_PIN)

        # Se lo stato cambia, invia dato
        if ir_state != last_state:

            # Crea payload JSON
            payload = {
                "ir_sensor": ir_state,
                "stato": "OSTACOLO" if ir_state == 0 else "LIBERO"
            }

            # Invia a ThingsBoard
            client.publish("v1/devices/me/telemetry", json.dumps(payload))

            # Stampa su terminale (debug)
            print("Inviato:", payload)

            # Aggiorna stato precedente
            last_state = ir_state

        # Piccola pausa per stabilità
        time.sleep(0.1)


except KeyboardInterrupt:
    print("\nChiusura programma...")

finally:
    client.loop_stop()
    client.disconnect()
    GPIO.cleanup()
    print("Pulizia GPIO completata")